from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request ,'index.html')


def about(request):
    return render(request ,'about.html')

def contact(request):
    return render(request ,'contact.html')

def course(request):
    return render(request,'course.html')


def team(request):
    return render(request,'team.html')


def circulars(request):
    return render(request,'circulars.html')